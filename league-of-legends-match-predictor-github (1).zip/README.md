# League of Legends Match Predictor

A binary match-outcome prediction project built with **PyTorch Logistic Regression**.

## Project overview

This notebook implements an end-to-end workflow:

1. Load and preprocess the League of Legends dataset
2. Split the data into training and test sets (80/20, stratified, `random_state=42`)
3. Standardize the input features
4. Implement logistic regression in PyTorch
5. Train the model for 1,000 epochs
6. Apply L2 regularization (`weight_decay=0.01`)
7. Evaluate the model with accuracy, precision, recall, F1-score, a confusion matrix, and an ROC curve
8. Save and reload the trained model
9. Compare learning rates
10. Inspect feature importance using model weights

## Results reported in the notebook

| Metric | Result |
|---|---:|
| Test accuracy | 95.00% |
| Precision | 95.05% |
| Recall | 95.05% |
| F1-score | 95.05% |
| Best learning rate | 0.01 |

The notebook's feature-weight ranking identifies `GOLD_DIFF` as the strongest feature by absolute weight, followed by `TOWERS_DIFF` and `KILLS_DIFF`.

## Files

- `Final_Project_League_of_Legends_Match_Predictor.ipynb` — full project notebook
- `requirements.txt` — Python dependencies
- `.gitignore` — excludes generated/local files

## Dataset

The notebook expects a CSV file named:

```text
league_of_legends_data_large.csv
```

Place this file in the same directory as the notebook before running it. The dataset is **not included** in this repository package; add it only if you have the right to redistribute it. If it is private or too large, document where it can be obtained instead.

## Run locally

```bash
python -m pip install -r requirements.txt
jupyter notebook Final_Project_League_of_Legends_Match_Predictor.ipynb
```

Run the notebook cells from top to bottom.

## Model artifact

The notebook saves the trained model weights as `logistic_regression_lol.pth` when the save/load section is executed. This generated file is not included in the package.

## Notes

The reported metrics are copied from the outputs saved in the submitted notebook. They have not been independently rerun as part of preparing this GitHub package.
