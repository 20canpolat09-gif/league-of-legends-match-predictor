# League of Legends Match Predictor

A machine-learning project for predicting League of Legends match outcomes.

## Project contents

- `images/roc_curve.png` — ROC curve shared with the project discussion.
- `images/confusion_matrix.png` — confusion matrix shared with the project discussion.
- `requirements.txt` — common Python packages for the notebook workflow.
- `.gitignore` — excludes temporary files and local environments.

## Add your notebook

Before publishing, add your original Jupyter notebook to the root folder, for example:

`League_of_Legends_Match_Predictor.ipynb`

The notebook is not included in this starter package because it has not been uploaded in this chat.

## Results shown in the supplied charts

- The ROC plot displays an AUC of 0.50.
- The confusion matrix displays the counts shown in the image.

Run the notebook from top to bottom to reproduce the analysis and results.

## Setup

```bash
python -m venv .venv
# Windows:
.venv\\Scripts\\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
```

## Notes

Add the dataset only if its license permits redistribution. Do not commit passwords, API keys, private data, or large generated files.
